
dic = {
"res1": ["price","cat","title1","http://ecx.images-amazon.com/images/I/51fAmVkTbyL._SY300_.jpg"],
"res2": ["price","cat","title2","http://ecx.images-amazon.com/images/I/51fAmVkTbyL._SY300_.jpg"],
"res3": ["price","cat","title3","http://ecx.images-amazon.com/images/I/51fAmVkTbyL._SY300_.jpg"],
"res4": ["price","cat","title4","http://ecx.images-amazon.com/images/I/51fAmVkTbyL._SY300_.jpg"],
"res5": ["price","cat","title5","http://ecx.images-amazon.com/images/I/51fAmVkTbyL._SY300_.jpg"],
"res6": ["price","cat","title6","http://ecx.images-amazon.com/images/I/51fAmVkTbyL._SY300_.jpg"],
"res7": ["price","cat","title7","http://ecx.images-amazon.com/images/I/51fAmVkTbyL._SY300_.jpg"],
"res8": ["price","cat","title8","http://ecx.images-amazon.com/images/I/51fAmVkTbyL._SY300_.jpg"],
"res9": ["price","cat","title9","http://ecx.images-amazon.com/images/I/51fAmVkTbyL._SY300_.jpg"],
"res10": ["price","cat","title10","http://ecx.images-amazon.com/images/I/51fAmVkTbyL._SY300_.jpg"],
"res11": ["price","cat","title11","http://ecx.images-amazon.com/images/I/51fAmVkTbyL._SY300_.jpg"],
"res12": ["price","cat","title12","http://ecx.images-amazon.com/images/I/51fAmVkTbyL._SY300_.jpg"],
"res13": ["price","cat","title13","http://ecx.images-amazon.com/images/I/51fAmVkTbyL._SY300_.jpg"],
"res14": ["price","cat","title14","http://ecx.images-amazon.com/images/I/51fAmVkTbyL._SY300_.jpg"],
"res15": ["price","cat","title15","http://ecx.images-amazon.com/images/I/51fAmVkTbyL._SY300_.jpg"],
"res16": ["price","cat","title16","http://ecx.images-amazon.com/images/I/51fAmVkTbyL._SY300_.jpg"]

}
