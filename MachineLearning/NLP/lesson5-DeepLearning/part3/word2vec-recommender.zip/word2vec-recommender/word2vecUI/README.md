# Word2Vec UI #

This repository contains the UI Word2Vec based recommendation engine.


### How do I get set up? ###

* Do git clone <repo name>
* Run app.py 