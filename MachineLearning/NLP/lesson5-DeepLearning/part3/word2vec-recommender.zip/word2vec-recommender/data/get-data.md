Amazon review data will be made available (for research purposes) on request. Please contact Julian McAuley (julian.mcauley@gmail.com) to obtain a link.

Sample data files available at: http://jmcauley.ucsd.edu/data/amazon/
