Rest of the models (User & Metadata) can be downloaded from https://s3.amazonaws.com/iasnlp-models/output_models.tar
